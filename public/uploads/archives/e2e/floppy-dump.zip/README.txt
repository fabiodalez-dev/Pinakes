Reusable Archives E2E fixture for electronic material.
